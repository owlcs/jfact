package jfact.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class TestTimeZone {
	public static void main(String[] args) throws Exception {
		List<Long> values = new ArrayList<Long>();
		String input = "2008-07-08T20:44:11.656+02:00";
		values.add(test1(input));
		input = "2008-07-08T20:44:11.656+03:00";
		values.add(test1(input));
		input = "2008-07-08T20:44:11.656Z";
		values.add(test1(input));
		input = "2008-07-08T20:44:11.656";
		values.add(test1(input));
		input = "2008-07-08T20:20:11.656+02:00";
		values.add(test1(input));
		input = "2008-07-08T20:25:11.656+03:00";
		values.add(test1(input));
		input = "2008-07-08T20:30:11.656Z";
		values.add(test1(input));
		input = "2008-07-08T20:35:11.656";
		values.add(test1(input));
		Collections.sort(values);
		for (long l : values) {
			GregorianCalendar cal = (GregorianCalendar) Calendar
					.getInstance();
			cal.setTimeInMillis(l);
			XMLGregorianCalendar calendar = DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(cal);
			System.out.println("TestTimeZone.main() " + calendar);
		}
	}

	public static long test1(String input) throws Exception {
		XMLGregorianCalendar calendar = DatatypeFactory.newInstance()
				.newXMLGregorianCalendar(input);
		if (calendar.getTimezone() == DatatypeConstants.FIELD_UNDEFINED) {
			// set it to 0 (UTC) in this case; not perfect but avoids indeterminate situations where two datetime literals cannot be compared
			calendar.setTimezone(0);
		}
		System.out
				.println("TestTimeZone.test1() "
						+ calendar.getTimezone()
						+ "\t timezone not defined? "
						+ (calendar.getTimezone() == DatatypeConstants.FIELD_UNDEFINED)
						);
		System.out.println("TestTimeZone.main() '" + input + "'");
		System.out.println("TestTimeZone.main() '" + calendar.toString() + "'");
		System.out.println("TestTimeZone.test1() "
				+ calendar.toGregorianCalendar().getTimeInMillis());
		return calendar.toGregorianCalendar().getTimeInMillis();
	}
}
