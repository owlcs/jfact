package jfact.test;



import junit.framework.TestCase;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class CorrectnessTest extends TestCase{
	public void testRun() throws Exception{
		OWLOntologyManager m = OWLManager.createOWLOntologyManager();
		Factory f = new Factory(m.getOWLDataFactory());
		OWLDataFactory df = m.getOWLDataFactory();
		OWLOntology o1 = m.createOntology();
		OWLClass z = f.getClass("z");
		OWLClass c = f.getClass("c");
		OWLNamedIndividual w = f.getInd("w");
		OWLNamedIndividual x = f.getInd("x");
		OWLObjectProperty p = f.getOProperty("p");
		m.addAxiom(o1, df.getOWLClassAssertionAxiom(z, w));
		m.addAxiom(o1, df.getOWLObjectPropertyAssertionAxiom(p, w, x));
		OWLClassExpression ex = df.getOWLObjectAllValuesFrom(p, c);
		m.addAxiom(o1, df.getOWLSubClassOfAxiom(z, ex));
		OWLReasoner reasoner=new JFactFactory().createReasoner(o1);
		
		OWLClassAssertionAxiom ax = df.getOWLClassAssertionAxiom(c, x);
		assertTrue("axiom was supposed to be entailed: "+ax+"\nfrom:\n"+o1.getLogicalAxioms().toString().replace(", ", ",\n"),reasoner.isEntailed(ax));
	}
	public class Factory {
		private OWLDataFactory f;
		private String ns="urn:test#";
		public Factory(OWLDataFactory f) {
			this.f=f;
		}
		public OWLClass getClass(String x) {
			return f.getOWLClass(IRI.create(ns+x));
		}
		public OWLObjectProperty getOProperty(String x) {
			return f.getOWLObjectProperty(IRI.create(ns+x));
		}
		public OWLDataProperty getDProperty(String x) {
			return f.getOWLDataProperty(IRI.create(ns+x));
		}
		public OWLNamedIndividual getInd(String x) {
			return f.getOWLNamedIndividual(IRI.create(ns+x));
		}
	}
}
