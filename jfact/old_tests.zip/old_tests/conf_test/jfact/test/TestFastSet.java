package jfact.test;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import uk.ac.manchester.cs.jfact.helpers.FastSet;
import uk.ac.manchester.cs.jfact.helpers.FastSetFactory;

public class TestFastSet {
	public static void main(String[] args) {
		Set<Integer> set = new TreeSet<Integer>();
		FastSet test = FastSetFactory.create();
		//	test.add(0);
		for (int i = -10; i < 10; i++) {
			//	System.out.println("TestFastSet.main() add "+i);
			set.add(i);
			test.add(i);
			//System.out.println("TestFastSet.main() "+set+"\n"+test+"\n************");
			if (!(set.contains(i) == test.contains(i))) {
				System.out.println("TestFastSet.main() broken contains");
			}
			//System.out.println("TestFastSet.main() remove "+i);
			set.remove(i);
			test.remove(i);
			//System.out.println("TestFastSet.main() "+set+"\n"+test+"\n************");
			if (!(set.contains(i) == test.contains(i))) {
				System.out.println("TestFastSet.main() broken contains");
			}
			//System.out.println("TestFastSet.main() add "+i);
			set.add(i);
			test.add(i);
			//System.out.println("TestFastSet.main() "+set+"\n"+test+"\n************");
		}
		for (int i = 20; i < 30; i++) {
			set.add(i);
			test.add(i);
			if (!(set.contains(i) == test.contains(i))) {
				System.out.println("TestFastSet.main() broken contains");
			}
			set.remove(i);
			test.remove(i);
			if (!(set.contains(i) == test.contains(i))) {
				System.out.println("TestFastSet.main() broken contains");
			}
			set.add(i);
			test.add(i);
		}
		for (int i : test.toIntArray()) {
			if (!set.contains(i)) {
				System.out.println("TestFastSet.main() broken iterator!");
			}
		}
		Iterator<Integer> it = set.iterator();
		while (it.hasNext()) {
			if (!test.contains(it.next())) {
				System.out
						.println("TestFastSet.main() broken iterator reverse!");
			}
		}
		System.out.println("TestFastSet.main() \n" + test + "\n"
				+ new TreeSet<Integer>(set));
	}
}
