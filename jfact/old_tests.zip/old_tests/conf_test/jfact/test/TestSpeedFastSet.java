package jfact.test;

import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import uk.ac.manchester.cs.jfact.helpers.FastSet;
import uk.ac.manchester.cs.jfact.helpers.FastSetFactory;
public class TestSpeedFastSet {
	static int max = 50000;
	static int low = -max;
	static int interval = 10;

	public static void main(String[] args) {
		testMain();
		testMain1();
	}

	public static void testMain() {
		Set<Integer> set1 = new TreeSet<Integer>();
		long l = System.currentTimeMillis();
		for (int i = low; i < max; i += interval) {
			set1.add(i);
		}
		System.out.println("regular " + (System.currentTimeMillis() - l)
				+ " set size: " + set1.size());
		Set<Integer> set2 = new TreeSet<Integer>();
		for (int i = low / 2; i < max / 2; i += interval) {
			set2.add(i);
		}
		l = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			sets_intersect(set1, set2);
		}
		System.out.println("regular " + (System.currentTimeMillis() - l));
	}

	public static void testMain1() {
		long l = System.currentTimeMillis();
		FastSet test1 = FastSetFactory.create();
		for (int i = low; i < max; i += interval) {
			test1.add(i);
		}
		System.out.println("fast    " + (System.currentTimeMillis() - l)
				+ " set size: " + test1.size());
		FastSet test2 = FastSetFactory.create();
		for (int i = low / 2; i < max / 2; i += interval) {
			test2.add(i);
		}
		l = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			test1.intersect(test2);
		}
		System.out.println("fast    " + (System.currentTimeMillis() - l));
	}

	private static <T> boolean sets_intersect(final Collection<T> s1,
			final Collection<T> s2) {
		Collection<T> it1 = s1;
		Collection<T> it2 = s2;
		if (s2.size() < s1.size()) {
			it1 = s2;
			it2 = s1;
		}
		for (T t : it1) {
			if (it2.contains(t)) {
				return true;
			}
		}
		return false;
		//		Set<T> s = new HashSet<T>(s1);
		//		s.retainAll(s2);
		//		return s.size() > 0;
	}
}
