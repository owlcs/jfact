//package jfact.test;
//
//import jfact.helpers.AbstractFastSet;
//import jfact.helpers.FastSet;
//
//public class FastSetImpl extends AbstractFastSet {
//	private LocalBitSet delegate;
//	private LocalBitSet negativedelegate;
//
//	public FastSetImpl() {
//	}
//
//	public int get(int i) {
//		return toIntArray()[i];
//	}
//
//	public LocalBitSet delegate() {
//		return delegate;
//	}
//
//	public LocalBitSet negativeDelegate() {
//		return negativedelegate;
//	}
//
//	private void initNegatives() {
//		if (negativedelegate == null) {
//			negativedelegate = new LocalBitSet();
//		}
//	}
//
//	private void initPositives() {
//		if (delegate == null) {
//			delegate = new LocalBitSet();
//		}
//	}
//
//	public void add(int e) {
//		if (e < 0) {
//			initNegatives();
//			negativedelegate.set(-e);
//		} else {
//			initPositives();
//			delegate.set(e);
//		}
//	}
//
//	public void addAll(FastSet c) {
//		if (c.delegate() != null) {
//			initPositives();
//			delegate.or(c.delegate());
//		}
//		if (c.negativeDelegate() != null) {
//			initNegatives();
//			negativedelegate.or(c.negativeDelegate());
//		}
//	}
//
//	public void clear() {
//		delegate = null;
//		negativedelegate = null;
//	}
//
//	public boolean contains(int o) {
//		if (o < 0) {
//			if (negativedelegate != null) {
//				return negativedelegate.get(-o);
//			} else {
//				return false;
//			}
//		}
//		if (delegate != null) {
//			return delegate.get(o);
//		} else {
//			return false;
//		}
//	}
//
//	public boolean containsAll(FastSet c) {
//		if (c.isEmpty()) {
//			return true;
//		}
//		if (isEmpty()) {
//			return false;
//		}
//		if (delegate != null && c.delegate() != null) {
//			LocalBitSet t = new LocalBitSet();
//			t.or(delegate);
//			t.and(c.delegate());
//			if (!t.equals(c.delegate())) {
//				return false;
//			}
//		} else {
//			return c.delegate() == null;
//		}
//		if (negativedelegate != null && c.negativeDelegate() != null) {
//			LocalBitSet t = new LocalBitSet();
//			t.or(negativedelegate);
//			t.and(c.negativeDelegate());
//			return t.equals(c.negativeDelegate());
//		} else {
//			return c.negativeDelegate() == null;
//		}
//	}
//
//	public boolean isEmpty() {
//		return delegate == null && negativedelegate == null;
//	}
//
//	public void remove(int o) {
//		if (o < 0) {
//			//	if (negativedelegate.get(-o)) {
//			if (negativedelegate != null) {
//				negativedelegate.clear(-o);
//				if (negativedelegate.isEmpty()) {
//					negativedelegate = null;
//				}
//			}
//		} else {
//			if (delegate != null) {
//				delegate.clear(o);
//				if (delegate.isEmpty()) {
//					delegate = null;
//				}
//			}
//		}
//	}
//
//	public int size() {
//		return (delegate == null ? 0 : delegate.cardinality())
//				+ (negativedelegate == null ? 0 : negativedelegate
//						.cardinality());
//	}
//
//	public int[] toIntArray() {
//		int[] toReturn = new int[(delegate == null ? 0 : delegate.cardinality())
//				+ (negativedelegate == null ? 0 : negativedelegate
//						.cardinality())];
//		int j = 0;
//		if (delegate != null) {
//			for (int i = delegate.nextSetBit(0); i >= 0; i = delegate
//					.nextSetBit(i + 1)) {
//				toReturn[j++] = i;
//			}
//		}
//		if (negativedelegate != null) {
//			for (int i = negativedelegate.nextSetBit(0); i >= 0; i = negativedelegate
//					.nextSetBit(i + 1)) {
//				toReturn[j++] = -i;
//			}
//		}
//		return toReturn;
//	}
//
//	public boolean intersect(FastSet f) {
//		return delegate != null && f.delegate() != null
//				&& delegate.intersects(f.delegate())
//				|| negativedelegate != null && f.negativeDelegate() != null
//				&& negativedelegate.intersects(f.negativeDelegate());
//	}
//}