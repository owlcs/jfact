package jfact.test;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class Test {
	public static void main(String[] args) throws Exception{
		OWLOntologyManager m=OWLManager.createOWLOntologyManager();
		OWLOntology o= m.createOntology();
		OWLDataFactory f=m.getOWLDataFactory();
		IRI i1=IRI.create("http://www.siemens-health.com/SiemensDemo/considerations.owl#OWLClass_01234978444300336000");
		IRI i2=IRI.create("http://www.siemens-health.com/SiemensDemo/START-HERE.owl#OWLClass_01236601472620087000");

		IRI i3=IRI.create("http://www.siemens-health.com/SiemensDemo/considerations2documentation.owl#OWLObjectProperty_01235005942259929000");
		IRI i4=IRI.create("http://www.siemens-health.com/SiemensDemo/considerations.owl#OWLClass_01234978444300336000");
		IRI i5=IRI.create("http://www.siemens-health.com/SiemensDemo/START-HERE.owl#OWLClass_01234978805488907000");
		IRI i6=IRI.create("http://www.siemens-health.com/SiemensDemo/considerations.owl#OWLClass_01234978444300336000");
		IRI i7=IRI.create("http://www.siemens-health.com/SiemensDemo/considerations.owl#OWLClass_01234978444300336000");

		m.addAxiom(o, f.getOWLDeclarationAxiom(f.getOWLClass(i7)));
		m.addAxiom(o, f.getOWLSubClassOfAxiom(f.getOWLClass(i2), f.getOWLObjectMinCardinality(0, f.getOWLObjectProperty(i3), f.getOWLClass(i4))));
		m.addAxiom(o, f.getOWLSubClassOfAxiom(f.getOWLClass(i5), f.getOWLClass(i6)));
		OWLReasoner r=new JFactFactory().createReasoner(o);
		r.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		System.out.println("Test.main() "+r.getSubClasses(f.getOWLClass(i1), true));
	}
}
