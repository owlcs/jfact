package jfact.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import uk.ac.manchester.cs.jfact.helpers.FastSet;
import uk.ac.manchester.cs.jfact.helpers.FastSetSimple;
@SuppressWarnings("unused")
public class TestLog {
	enum FastSetMethods {
		isEmpty {
			@Override
			void run(FastSet object,  Object arg) {
				object.isEmpty();
			}
		},
		size {
			@Override
			void run(FastSet object, Object arg) {
				object.size();
			}
		},
		clear {
			@Override
			void run(FastSet object, Object arg) {
				object.clear();
			}
		},
		toIntArray {
			@Override
			void run(FastSet object, Object arg) {
				object.toIntArray();
			}
		},
		add {
			@Override
			void run(FastSet object, Object arg) {
				
				object.add(((Integer) arg).intValue());
			}
		},
		contains {
			@Override
			void run(FastSet object, Object arg) {
				object.contains(((Integer) arg).intValue());
			}
		},
		remove {
			@Override
			void run(FastSet object, Object arg) {
				object.remove(((Integer) arg).intValue());
			}
		},
		addAll {
			@Override
			void run(FastSet object, Object arg) {
				object.addAll((FastSet) arg);
			}
		},
		containsAll {
			@Override
			void run(FastSet object, Object arg) {
				object.containsAll((FastSet) arg);
			}
		},
		intersect {
			@Override
			void run(FastSet object, Object arg) {
				object.intersect((FastSet) arg);
			}
		};
		abstract void run(FastSet object, Object arg);
	}

	public static void mainT(String[] args) throws Exception {
		String logName = "../ReasonersTest/FastSet.log";
		//Map<String, Long> lastOccurrence = 
			checkLastOccurrence(logName);
	}

	public static void main(String[] args) throws Exception {
		Map<String, FastSet> map1 = new HashMap<String, FastSet>();
		Map<String, FastSet> map2 = new HashMap<String, FastSet>();
		Map<FastSetMethods, Long> calls = new LinkedHashMap<FastSetMethods, Long>();
		Map<FastSetMethods, Long> nanoseconds1 = new LinkedHashMap<FastSetMethods, Long>();
		Map<FastSetMethods, Long> nanoseconds2 = new LinkedHashMap<FastSetMethods, Long>();
		for (FastSetMethods f : FastSetMethods.values()) {
			calls.put(f, 0L);
			nanoseconds1.put(f, 0L);
			nanoseconds2.put(f, 0L);
		}
		String logName = "../logtest.log";
		//	String logName = "../test.log";
		//Map<String, Long> lastOccurrence = checkLastOccurrence(logName);
		BufferedReader r = new BufferedReader(new InputStreamReader(
				new FileInputStream(logName)));
		String line = r.readLine();
		long l = 0;
		int size = 0;
		int sum = 0;
		int max = 0;
		System.out.println("TestLog.main() ready to go...");
		//	System.in.read();
		CallBack simple = new CallBack() {
			public FastSet getSet() {
				return getSimpleSet();
			}
		};
		CallBack impl = new CallBack() {
			public FastSet getSet() {
				return getImplSet();
			}
		};
		while (line != null) {
			if (l % 1000000 == 0) {
				System.out.println(l / 1000000);
			}
			l++;
			if (line.startsWith("drop")) {
				String key = line.replace("drop ", "");
				FastSet f = map1.get(key);
				map2.remove(key);
				map1.remove(key);
				if (f != null) {
					size++;
					sum += f.size();
					if (max < f.size()) {
						max = f.size();
					}
				}
			} else {
				int dot = line.indexOf(".");
				int par = line.indexOf("(");
				String obj = line.substring(0, dot);
				String method = line.substring(dot + 1, par);
				Object arg2 = null;
				String arg = line.substring(par + 1, line.indexOf(")"));
				FastSetMethods toCall = FastSetMethods.valueOf(method);
				if (toCall == FastSetMethods.addAll) {
					//	System.out.println("TestLog.main() addAll "+map1.get(obj)+"\t"+map1.get(arg));
				}
				if (toCall == FastSetMethods.add
						|| toCall == FastSetMethods.contains
						|| toCall == FastSetMethods.remove) {
					arg2 = Integer.parseInt(arg);
				}
				calls.put(toCall, calls.get(toCall) + 1);
				long nanoseconds = main1(map1, obj, toCall, arg, arg2, simple);
				nanoseconds1
						.put(toCall, nanoseconds1.get(toCall) + nanoseconds);
				nanoseconds += main1(map2, obj, toCall, arg, arg2, impl);
				nanoseconds2
						.put(toCall, nanoseconds2.get(toCall) + nanoseconds);
				if (!map1.get(obj).equals(map2.get(obj))) {
					System.out
							.println("TestLog.main(): ERROR " + obj + "\t"
									+ arg + "\n" + map1.get(obj) + "\n"
									+ map2.get(obj));
					return;
					//					main1(map1, obj, toCall, arg, arg2, simple);
				}
			}
			line = r.readLine();
		}
		//		System.out.println("TestLog.main() elapsed nanoseconds: "
		//				+ nanoseconds1 + "\t" + nanoseconds2);
		for (Map.Entry<?,?> e : calls.entrySet()) {
			System.out.println("Calls:\t" + e.getKey() + "\t" + e.getValue());
		}
		for (Map.Entry<?,?> e : nanoseconds1.entrySet()) {
			System.out.println("Simple:\t" + e.getKey() + "\t" + e.getValue());
		}
		for (Map.Entry<?,?> e : nanoseconds2.entrySet()) {
			System.out.println("Impl:\t" + e.getKey() + "\t" + e.getValue());
		}
		System.gc();
		System.out.println("TestLog.main() " + Runtime.getRuntime().maxMemory()
				+ " " + Runtime.getRuntime().freeMemory());
		stats(map1, sum, max, size);
		stats(map2, sum, max, size);
		if (map1.equals(map2)) {
			System.out.println("Maps are equal");
		}
	}

	private static Map<String, Long> checkLastOccurrence(String logName)
			throws Exception {
		Map<String, Long> map = new HashMap<String, Long>();
		BufferedReader r = new BufferedReader(new InputStreamReader(
				new FileInputStream(logName)));
		String line = r.readLine();
		long l = 0;
		while (line != null) {
			l++;
			int dot = line.indexOf(".");
			int par = line.indexOf("(");
			String obj = line.substring(0, dot);
			map.put(obj, l);
			String arg = line.substring(par + 1, line.indexOf(")"));
			if (arg.startsWith("s")) {
				map.put(arg, l);
			}
			line = r.readLine();
		}
		r.close();
		System.out.println("TestLog.checkLastOccurrence() " + map.size());
		PrintStream p = new PrintStream("../logtest.log");
		r = new BufferedReader(new InputStreamReader(new FileInputStream(
				logName)));
		line = r.readLine();
		l = 0;
		while (line != null) {
			l++;
			p.println(line);
			if (l % 1000 == 0) {
				List<String> keysToRemove = new ArrayList<String>();
				for (Map.Entry<String, Long> e : map.entrySet()) {
					if (e.getValue() < l) {
						p.println("drop " + e.getKey());
						keysToRemove.add(e.getKey());
					}
				}
				for (String s : keysToRemove) {
					map.remove(s);
				}
			}
			line = r.readLine();
		}
		for (Map.Entry<String, Long> e : map.entrySet()) {
			if (e.getValue() < l) {
				p.println("drop " + e.getKey());
			}
		}
		p.close();
		return map;
	}

	public static void stats(Map<String, FastSet> map1, int sum, int max,
			int size) {
		for (FastSet s : map1.values()) {
			sum += s.size();
			if (s.size() > max) {
				max = s.size();
			}
		}
		System.out.println("TestLog.main() avg size: " + sum + "/"
				+ map1.size() + "=" + (double) sum / (map1.size() + size));
		System.out.println("TestLog.main() top size: " + max);
	}

	public static long main1(Map<String, FastSet> map, String obj,
			FastSetMethods m, String arg, Object arg2, CallBack callback)
			throws Exception {
		if (!map.containsKey(obj)) {
			map.put(obj, callback.getSet());
		}
		if (arg.startsWith("s") && map.get(arg) == null) {
			map.put(arg, callback.getSet());
		}
		if (arg2 == null) {
			arg2 = map.get(arg);
		}
		// = arg.startsWith("s") ? map.get(arg) : arg;
		long start = System.nanoTime();
		m.run(map.get(obj), arg2);
		long toReturn = System.nanoTime() - start;
		return toReturn;
	}

	interface CallBack {
		FastSet getSet();
	}

	 static FastSet getSimpleSet() {
		return new FastSetSimple();
	}

	 static FastSet getImplSet() {
		return null;
		//return new FastSetImpl();
	}
}
// FastSetImpl
//TestLog.main() elapsed nanoseconds: 1993251000
//capture memory snapshot
//TestLog.main() 4185587712 607009648
//FastSetSimple
//TestLog.main() elapsed nanoseconds: 2180963000
//capture memory snapshot
//TestLog.main() 4185587712 639998088
//estLog.main() 4185587712 514 003 992
