package jfact.test;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class CheckFunnyBoss {
	public static void main(String[] args) throws Exception {
		OWLOntologyManager m = OWLManager.createOWLOntologyManager();
		OWLOntology o = m.createOntology();
		final OWLDataFactory f = m.getOWLDataFactory();
		OWLObjectProperty vehicle = f
				.getOWLObjectProperty(IRI.create("urn:test:vehicle"));
		OWLClass boss = f.getOWLClass(IRI.create("urn:test:boss"));
		OWLClass bently = f.getOWLClass(IRI.create("urn:test:bently"));
		OWLClass personnel = f.getOWLClass(IRI.create("urn:test:personnel"));
		m.addAxiom(
				o,
				f.getOWLSubClassOfAxiom(
						boss,
						f.getOWLObjectIntersectionOf(
								personnel,
								f.getOWLObjectAllValuesFrom(vehicle, bently),
								f.getOWLObjectSomeValuesFrom(vehicle, bently),
								f.getOWLObjectSomeValuesFrom(vehicle,
										f.getOWLObjectComplementOf(bently)))));
		m.addAxiom(o, f.getOWLFunctionalObjectPropertyAxiom(vehicle));
		OWLReasoner r = new JFactFactory().createReasoner(o);
		System.out.println("CheckFunnyBoss.main() boss satisfiable: "
				+ r.isSatisfiable(boss));
	}
}
