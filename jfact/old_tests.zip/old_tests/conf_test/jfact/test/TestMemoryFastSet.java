package jfact.test;

import java.util.HashSet;
import java.util.Set;

import uk.ac.manchester.cs.jfact.helpers.FastSet;
import uk.ac.manchester.cs.jfact.helpers.FastSetFactory;
public class TestMemoryFastSet {
	public static final int MAX = 100000;

	public static void main(String[] args) throws Exception {
		int i = 0;
		while (i < 10) {
			i++;
			testMain1();
			//			System.in.read();
			//			testMain1();
			//			System.in.read();
		}
	}

	public static void testMain() {
		int max = 500;
		int low = -max;
		long l = System.currentTimeMillis();
		for (int number = 0; number < MAX; number++) {
			Set<Integer> set1 = new HashSet<Integer>();
			for (int i = low; i < max; i += 10) {
				set1.add(i);
			}
		}
		System.out.println("regular " + (System.currentTimeMillis() - l));
	}

	public static void testMain1() {
		int max = 500;
		int low = -max;
		long l = System.currentTimeMillis();
		for (int number = 0; number < MAX; number++) {
			FastSet set1 = FastSetFactory.create();
			for (int i = low; i < max; i += 10) {
				set1.add(i);
			}
		}
		System.out.println("fast " + (System.currentTimeMillis() - l));
	}
}
