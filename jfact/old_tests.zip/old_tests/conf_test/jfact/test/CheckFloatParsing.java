package jfact.test;

import uk.ac.manchester.cs.jfact.kernel.datatype.Datatypes;

public class CheckFloatParsing {
	public static void main(String[] args) {
		String[] arguments = new String[] {"1","1.1","1.1e-2",  "-inf", "INF", "43.4","-43.4", "1/2", "-1/2" };
		for (String s : arguments) {
			System.out.println("CheckFloatParsing.main()"
					+ Datatypes.parseFloat(s));
		}
	}
}
