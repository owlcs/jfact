package jfact.test;

import uk.ac.manchester.cs.jfact.helpers.FastSet;
import uk.ac.manchester.cs.jfact.helpers.FastSetFactory;

public class TestFastSetRemoveAt {
	public static void main(String[] args) {
		FastSet f=FastSetFactory.create();
		f.add(1);
		f.add(2);
		f.add(3);
		f.add(4);
		System.out.println("TestFastSetRemoveAt.main() "+f);
		f.removeAt(2);
		System.out.println("TestFastSetRemoveAt.main() "+f);
		f.removeAt(2);
		System.out.println("TestFastSetRemoveAt.main() "+f);
		f.removeAt(5);f.removeAt(-1);
		System.out.println("TestFastSetRemoveAt.main() "+f);
		
	}
}
