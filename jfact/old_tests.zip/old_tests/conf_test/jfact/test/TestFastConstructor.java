package jfact.test;

import uk.ac.manchester.cs.jfact.helpers.FastSetSimple;


public class TestFastConstructor {
	public static void main(String[] args) {
		int max = Integer.MAX_VALUE;
		long l = System.currentTimeMillis();
		for (int i = 0; i < max; i++) {
			//new FastSetImpl();
		}
		System.out.println("impl\t " + (System.currentTimeMillis() - l));
		l = System.currentTimeMillis();
		for (int i = 0; i < max; i++) {
			new FastSetSimple();
		}
		System.out.println("simple\t " + (System.currentTimeMillis() - l));
	}
}
