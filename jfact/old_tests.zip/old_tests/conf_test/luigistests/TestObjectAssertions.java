package luigistests;

import java.io.File;
import java.util.Set;

import junit.framework.TestCase;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.util.AutoIRIMapper;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class TestObjectAssertions extends TestCase {
	/**
	 * @param args
	 */
	public void testPerformanceGetValues() throws Exception {
		OWLOntologyManager ontologyManager = OWLManager
				.createOWLOntologyManager();
		File base = new File("luigi_test1");
		File url = new File(base, "family20.rdf.owl");
		AutoIRIMapper mapper = new AutoIRIMapper(base, true);
		ontologyManager.addIRIMapper(mapper);
		OWLOntology ontology = ontologyManager.loadOntology(IRI.create(url));
		JFactFactory factory = new JFactFactory();
		OWLReasoner reasoner = factory.createReasoner(ontology);
		System.out.println("TestObjectAssertions.testPerformanceGetValues() "+reasoner.isConsistent());
		Set<OWLNamedIndividual> individuals = ontology
				.getIndividualsInSignature();
		Set<OWLObjectProperty> objectProperties = ontology
				.getObjectPropertiesInSignature();
		String template = "Computing fillers for %d individuals on %d object properties ";
		System.out.println(String.format(template, individuals.size(),
				objectProperties.size()));
		for (OWLNamedIndividual owlNamedIndividual : individuals) {
			for (OWLObjectProperty owlObjectProperty : objectProperties) {
				long start = System.currentTimeMillis();
				NodeSet<OWLNamedIndividual> objectPropertyValues = reasoner
						.getObjectPropertyValues(owlNamedIndividual,
								owlObjectProperty);
				long elapsed = System.currentTimeMillis() - start;
				System.out.println(String.format(
						"After %d millisecs inferred %s %s %s ", elapsed,
						owlNamedIndividual, owlObjectProperty,
						objectPropertyValues.getFlattened()));
			}
		}
	}
}
