package yatitests;

import java.io.File;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.profiles.OWL2DLProfile;
import org.semanticweb.owlapi.profiles.OWLProfileReport;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class Dolce {
	public static void main(String[] args) throws Exception {
		OWLOntologyManager m = OWLManager.createOWLOntologyManager();
		OWLOntology o = m.loadOntologyFromOntologyDocument(new File("yati_test/dolce-ro.owl"));
		OWL2DLProfile p = new OWL2DLProfile();
		OWLProfileReport rep = p.checkOntology(o);
		System.out.println(rep.toString());
		
		OWLReasoner r = new JFactFactory().createReasoner(o);
		r.precomputeInferences(InferenceType.values());
	}
}
