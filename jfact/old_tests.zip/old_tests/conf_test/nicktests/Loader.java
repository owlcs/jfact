package nicktests;

import java.io.File;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.util.AutoIRIMapper;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class Loader {
	private static class ReasonerTester extends ReloadingTestCallBack {
		public ReasonerTester(OWLOntologyManager m, OWLOntology o, String s) {
			super(m, o, s);
		}

		@Override
		protected void initReasoner() {
			this.r = new JFactFactory().createReasoner(o1);
			r.precomputeInferences(InferenceType.values());
		}
	}

	public static void main(String[] args) throws Exception {
		File folder = new File("nick_test/test");
//		for (File f : folder.listFiles()) {
//			if (f.getName().endsWith(".owl") || f.getName().endsWith(".rdf")) {
//				OWLOntologyManager m = OWLManager.createOWLOntologyManager();
//				m.addIRIMapper(new AutoIRIMapper(folder, true));
//				OWLOntology o1 = m.loadOntologyFromOntologyDocument(f);
//				System.out.println("Loader.main() " + f.getName() + "...");
//				ReasonerTester tester = new ReasonerTester(m, o1, "");
//				System.out.println("Loader.main() classified");
//				tester.execute();
//				System.out.println("Loader.main() " + f.getName() + " done");
//			}
//		}
		folder = new File("nick_test/ontologies");
		for (File f : folder.listFiles()) {
			if (f.getName().endsWith(".owl") || f.getName().endsWith(".rdf")) {
				OWLOntologyManager m = OWLManager.createOWLOntologyManager();
				m.addIRIMapper(new AutoIRIMapper(folder, true));
				OWLOntology o1 = m.loadOntologyFromOntologyDocument(f);
				System.out.println("Loader.main() " + f.getName() + "...");
				ReasonerTester tester = new ReasonerTester(m, o1, "");
				System.out.println("Loader.main() classified");
				tester.execute();
				System.out.println("Loader.main() " + f.getName() + " done");
			}
		}
	}
}
