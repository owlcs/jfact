package nicktests;

import junit.framework.TestCase;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class TopObjectPropertyTest extends TestCase{
	public void testReasoner3(){
		try {
		OWLOntologyManager mngr = OWLManager.createOWLOntologyManager();
		OWLOntology ont = mngr.createOntology();
		OWLDataFactory df = mngr.getOWLDataFactory();

		final OWLReasonerFactory fac = new JFactFactory();
		OWLReasoner r = fac.createNonBufferingReasoner(ont);

		OWLDataProperty p = df.getOWLDataProperty(IRI.create("http://example.com/p"));

		// just so p is known in the ontology
		mngr.applyChange(new AddAxiom(ont, df.getOWLFunctionalDataPropertyAxiom(p)));

		assertTrue(r.isEntailed(df.getOWLSubClassOfAxiom(df.getOWLDataSomeValuesFrom(p, df.getIntegerOWLDatatype()),
		df.getOWLDataSomeValuesFrom(p, df.getTopDatatype()))));
		}
		catch (Exception e) {
		e.printStackTrace();
		fail();
		}
		}

	public void testReasoner4(){
		try {
		OWLOntologyManager mngr = OWLManager.createOWLOntologyManager();
		OWLOntology ont = mngr.createOntology();

		final OWLReasonerFactory fac = new JFactFactory();
		OWLReasoner r = fac.createNonBufferingReasoner(ont);

		assertFalse(r.getTopDataPropertyNode().getEntities().isEmpty());
		}
		catch (Exception e) {
		e.printStackTrace();
		fail();
		}
		}

	public void testReasoner5() {
		try {
			OWLOntologyManager mngr = OWLManager.createOWLOntologyManager();
			OWLOntology ont = mngr.createOntology();
			mngr.addAxiom(ont, mngr.getOWLDataFactory().getOWLDataPropertyDomainAxiom(mngr.getOWLDataFactory().getOWLDataProperty(IRI.create("urn:test:datap1")), mngr.getOWLDataFactory().getOWLNothing()));
			final OWLReasonerFactory fac = new JFactFactory();
			OWLReasoner r = fac.createNonBufferingReasoner(ont);
			assertFalse(r.getBottomDataPropertyNode().getEntities().isEmpty());
			assertTrue(r.getBottomDataPropertyNode().getEntities().size()==2);
		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}
	}
}
