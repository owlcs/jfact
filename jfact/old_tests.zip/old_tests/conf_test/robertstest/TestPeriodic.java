package robertstest;

import java.io.File;

import junit.framework.TestCase;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.TimedConsoleProgressMonitor;
import org.semanticweb.owlapi.util.AutoIRIMapper;

import uk.ac.manchester.cs.jfact.JFactFactory;

public class TestPeriodic extends TestCase {
	public static void main(String[] args) throws Exception {
		OWLOntologyManager ontologyManager = OWLManager
				.createOWLOntologyManager();
		File base = new File("robertstest");
		File url = new File(base, "periodic.owl");
		AutoIRIMapper mapper = new AutoIRIMapper(base, true);
		ontologyManager.addIRIMapper(mapper);
		OWLOntology ontology = ontologyManager.loadOntology(IRI.create(url));

		OWLReasoner reasoner = new JFactFactory().createReasoner(ontology,
				new SimpleConfiguration(new TimedConsoleProgressMonitor()));
		System.out.println("TestPeriodic.main()");
		System.in.read();
		reasoner.precomputeInferences(InferenceType.values());
	}
}
