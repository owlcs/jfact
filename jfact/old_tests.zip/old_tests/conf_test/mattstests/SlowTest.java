package mattstests;

import java.io.File;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.TimedConsoleProgressMonitor;

import conformance.Factory;


public class SlowTest {
	public static void main(String[] args) throws Exception{
		OWLOntologyManager m=OWLManager.createOWLOntologyManager();
		
		OWLOntology o = m.loadOntologyFromOntologyDocument(new File("matt_test3/ontology.owl"));
		System.out.println("SlowTest.main()");
		System.in.read();
		OWLReasoner r=Factory.factory().createReasoner(o, new SimpleConfiguration(new TimedConsoleProgressMonitor()));
		r.precomputeInferences(InferenceType.values());
	}
}
