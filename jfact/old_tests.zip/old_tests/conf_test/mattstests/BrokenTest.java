package mattstests;

import java.io.File;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import conformance.Factory;


public class BrokenTest {
	public static void main(String[] args) throws Exception{
		OWLOntologyManager m=OWLManager.createOWLOntologyManager();
		
		OWLOntology o = m.loadOntologyFromOntologyDocument(new File("matt_test2/ontology.owl"));
		OWLReasoner r=Factory.factory().createReasoner(o);
		r.precomputeInferences(InferenceType.values());
	}
}
