package mattstests;

import java.io.File;

import conformance.JUnitRunnerFromFile;
import conformance.TestClasses;


public class DebugTest {
	public static void main(String[] args) throws Exception{
		JUnitRunnerFromFile runner=new JUnitRunnerFromFile(new File("matt_test4/ontology.owl"),new File("matt_test4/entailments.owl"),"", TestClasses.POSITIVE_IMPL, "");
		runner.run();	}
}
