package mattstests;

import java.io.File;

import conformance.Factory;
import conformance.JUnitRunnerFromFile;
import conformance.TestClasses;

public class InferenceTest {
	public static void main(String[] args) throws Exception {
		JUnitRunnerFromFile runner = new JUnitRunnerFromFile(new File(
				"matt_test1/ontology.owl"), new File(
				"matt_test1/entailments.owl"), "", TestClasses.POSITIVE_IMPL,
				"");
		runner.setReasonerFactory(Factory.factory());
		runner.run();
	}
}
